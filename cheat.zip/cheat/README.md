﻿# 👾 About
An extremely simple, external CS:GO bhop & glow ESP made in my first [video](https://youtu.be/sboI-i_qJuU).

## ☂️ Usage
1. Watch the [video](https://youtu.be/sboI-i_qJuU)
2. Clone the repository
3. Update offsets (shown in video)
4. Build in `Release | x86`
5. Enjoy!

## 🗿 Disclaimer
I am not responsible for anything that happens when you use this software. Cheers.